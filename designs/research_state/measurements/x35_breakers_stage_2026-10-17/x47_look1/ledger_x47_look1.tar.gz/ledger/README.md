# The eval COUNT ledger (`gen3_eval_count_row_v2`)

Append-only. One row per (batch x matchup). NEVER edit, move or delete a file here: a correction is a new row
that `supersedes` the old one. Spec: `designs/endstate/design_evaluation.md` §0b. Code:
`src/agents/training/eval_ledger/`. Check it: `python -m main.eval_ledger audit`.
(`.ledger_index/` is the one exception: a CACHE derived from the streams, safe to delete and rebuilt on demand.)
